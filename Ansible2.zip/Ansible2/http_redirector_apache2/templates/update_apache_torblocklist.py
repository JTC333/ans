#!/usr/bin/python3

# https://check.torproject.org/torbulkexitlist
# https://www.dan.me.uk/torlist/ - seems more comprehensive

import requests
import os

url = "https://check.torproject.org/torbulkexitlist"

r = requests.get(url)

# Transforming the data returned into JSON format
data = r.text

allLines = "# TOR Exit Nodes\n\n"

for line in data.splitlines():
    allLines += "RewriteCond     expr    \"-R '"+line+"'\"	[OR]\n"

allLines += "RewriteCond %{ENV:OverrideBlock} ^$"
allLines += "RewriteRule . - [E=reject_reason:block-tor,R=404,L]"

f = open("/etc/apache2/conf-available/block_tor.conf", "w")
f.write(allLines)
f.close()
os.system("service apache2 restart")
