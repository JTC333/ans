Ansible role that allows for quickly deploying a DNS redirector to an existing server.

Simply follow the README under the Environments/C2-Staging folder to run.

This role will apply to instances created via the main_c2_dnsRedir.tf terraform module.

It uses socat to tunnel UDP traffic from port 53 to the local tcp port 5353.

Once successfully open a reverse ssh tunnel with to the redirector instance(s) from the RT Base server:
screen -a -d -S dnsTunnel ssh -N -i sshCert.pem -R 5353:localhost:5353 ubuntu@<AWS_DNS_Server_IP>

Last step is then to redirect the tcp traffic back to udp 53 for the cobalt strike beacon
screen -d -m socat -v TCP-LISTEN:5353,fork UDP:127.0.0.1:53
